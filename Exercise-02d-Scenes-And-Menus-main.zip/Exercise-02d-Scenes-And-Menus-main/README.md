# Exercise-02d-Scenes-And-Menus

Exercise for MSCH-C220

A user-controlled ship for a space-shooter game. Recently added the ability to shoot at asteroids. Created in Unity.

## Implementation
Created main/ end-game screen 
created a hud that displays the score, lives, and time from the start


Created using [Unity 2022.3.45f](https://unity.com)

Assets are provided by [Kenney.nl](https://kenney.nl/assets/space-shooter-extension), provided under a [CC0 1.0 Public Domain License](https://creativecommons.org/publicdomain/zero/1.0/).

The explosion spritesheet was released into the public domain by [StumpyStrust](https://opengameart.org/content/explosion-sheet)

## References
None

## Future Development
None

## Created by
Leya Flenoy
